'use strict';

(() => {
  try { globalThis.__oneBrainContentCleanup?.(); } catch {}
  const SITE = location.hostname === 'chatgpt.com' ? 'chatgpt' : location.hostname === 'claude.ai' ? 'claude' : location.hostname === 'gemini.google.com' ? 'gemini' : location.hostname === 'chat.deepseek.com' ? 'deepseek' : location.hostname === 'console.groq.com' && location.pathname.startsWith('/playground') ? 'groq' : ['perplexity.ai', 'www.perplexity.ai'].includes(location.hostname) ? 'perplexity' : null;
  const API = globalThis.browser || globalThis.chrome;
  const adapter = SITE && globalThis.OneBrainAdapters?.[SITE];
  const editorTools = globalThis.OneBrainEditorInsertion;
  const searchIntent = globalThis.OneBrainSearchIntent;
  const backgroundMessage = globalThis.OneBrainBackgroundMessage;
  const smartSave = globalThis.OneBrainSmartSave;
  const insertionGuardModule = globalThis.OneBrainInsertionGuard;
  const manualContext = globalThis.OneBrainManualContext;
  const layoutFallbackModule = globalThis.OneBrainLayoutFallback;
  const chatLoader = globalThis.OneBrainChatLoader;
  const floatingLayout = globalThis.OneBrainFloatingLayout;
  const messageActions = globalThis.OneBrainMessageActions;
  const autoSaveGuard = globalThis.OneBrainAutoSaveGuard;
  if (!SITE || !API || !adapter || !editorTools || !searchIntent || !backgroundMessage || !smartSave || !insertionGuardModule || !manualContext || !layoutFallbackModule || !chatLoader || !floatingLayout || !messageActions || !autoSaveGuard) return;
  const timers = new Set();
  const eventController = new AbortController();
  let stopped = false, staleToastShown = false, adapterCleanup = () => {};
  let runtimeMessageListener = null, storageChangedListener = null;
  function scheduleTimeout(callback, delay) {
    if (stopped) return null;
    let id;
    id = setTimeout(() => { timers.delete(id); if (!stopped) callback(); }, delay);
    timers.add(id);
    return id;
  }
  function clearScheduledTimeout(id) { if (id != null) { clearTimeout(id); timers.delete(id); } }
  function staleToast() {
    if (staleToastShown) return;
    staleToastShown = true;
    const node = document.createElement('div'); node.className = 'one-brain-extension-toast one-brain-extension-ui';
    node.append(document.createTextNode('One Brain extension was updated. Reload this page. '));
    const reload = document.createElement('button'); reload.type = 'button'; reload.textContent = 'Reload';
    reload.addEventListener('click', () => location.reload()); node.append(reload); document.body.append(node);
  }
  function stopContentScript(showToast = false) {
    if (stopped) { if (showToast) staleToast(); return; }
    stopped = true;
    try { adapterCleanup(); } catch {}
    eventController.abort();
    if (runtimeMessageListener) API.runtime.onMessage.removeListener?.(runtimeMessageListener);
    if (storageChangedListener) API.storage.onChanged.removeListener?.(storageChangedListener);
    for (const timer of timers) clearTimeout(timer);
    timers.clear();
    modal?.remove(); modal = null;
    document.querySelectorAll('.one-brain-extension-ui').forEach((node) => node.remove());
    if (showToast) staleToast();
  }
  globalThis.__oneBrainContentCleanup = () => stopContentScript(false);
  const askBackground = backgroundMessage.createBackgroundMessenger(API.runtime, () => stopContentScript(true));
  const DEFAULTS = { enabled: true, showButtons: true, suggestOnSend: false, autoSaveMessages: false, smartSaveEnabled: true, autoSaveFinishedReplies: autoSaveGuard.DEFAULT_AUTO_SAVE_FINISHED_REPLIES, memoryMode: 'off', memoryPhrases: searchIntent.DEFAULT_MEMORY_PHRASES, insertWithoutAsking: false, tokenBudget: 1500, contextFormat: 'context' };
  let config = { ...DEFAULTS };
  let modal = null;
  let lastInsertedBlock = '';
  let pendingSends = [];
  let chatState = { enabled: true, excludeIds: [] };
  let chatKeyValue = '';
  let chatRoutePath = location.pathname;
  let autoTimer = null;
  const insertedDrafts = new Set();
  const insertionGuard = insertionGuardModule.createInsertionGuard();
  let programmaticInsertUntil = 0, lastProcessedDraft = '', loopToastShown = false;
  const sourceColors = { chatgpt: '#65a7ff', claude: '#d79a63', gemini: '#8c7bf0', groq: '#75c88a', deepseek: '#4ca8be', perplexity: '#35c9f0', openai: '#65a7ff' };

  async function getChatKey() {
    if (chatKeyValue) return chatKeyValue;
    const conversationId = location.pathname.split('/').filter(Boolean).at(-1) || 'unknown';
    const bytes = new TextEncoder().encode(`${SITE}\u0000${conversationId}`);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    chatKeyValue = [...new Uint8Array(digest)].map((part) => part.toString(16).padStart(2, '0')).join('');
    return chatKeyValue;
  }

  function toast(message, isError = false) {
    if (stopped) return null;
    let node = document.querySelector('.one-brain-extension-toast');
    if (!node) { node = document.createElement('div'); node.className = 'one-brain-extension-toast one-brain-extension-ui'; document.body.append(node); }
    node.textContent = message;
    node.dataset.error = String(isError);
    clearScheduledTimeout(node._hideTimer);
    node._hideTimer = scheduleTimeout(() => node.remove(), 3800);
  }

  function toastWithUndo(message, undo, { duration = 3000, successMessage = 'Insertion undone.' } = {}) {
    if (stopped) return null;
    let node = document.querySelector('.one-brain-extension-toast');
    if (!node) { node = document.createElement('div'); node.className = 'one-brain-extension-toast one-brain-extension-ui'; document.body.append(node); }
    node.replaceChildren(document.createTextNode(message));
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Undo';
    button.addEventListener('click', async () => { clearScheduledTimeout(node._hideTimer); button.disabled = true; try { const result = await undo(); if (result === true || result?.ok) toast(successMessage); else toast('Could not undo this save.', true); } catch { toast('Could not undo this save.', true); } });
    node.append(' ', button);
    node.dataset.error = 'false';
    clearScheduledTimeout(node._hideTimer);
    node._hideTimer = scheduleTimeout(() => node.remove(), duration);
  }

  function readText(element) {
    if (!element) return '';
    const copy = element.cloneNode(true);
    copy.querySelectorAll('.one-brain-extension-ui').forEach((node) => node.remove());
    return String(copy.innerText || copy.textContent || '').trim();
  }

  function cleanOutgoingText(value) {
    return editorTools.stripContextBlocks(String(value || '')).trim();
  }

  function looksLikeLog(text) {
    const lines = String(text).split(/\r?\n/).filter((line) => line.trim());
    if (lines.length < 2) return /^(?:traceback|\s*at\s+\S+\s*\(|(?:GET|POST|PUT|DELETE)\s+\/|\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d)/i.test(text.trim());
    const signatures = lines.filter((line) => /^(?:\s*at\s+\S+\s*\(|\s*File\s+['"]|\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d|\s*(?:DEBUG|INFO|WARN|ERROR)\s*[:|]|(?:GET|POST|PUT|DELETE)\s+\/|\s*\[\d{2}:\d{2}:\d{2}\])/i.test(line));
    return signatures.length >= 2 || signatures.length / lines.length >= 0.45;
  }

  function draftText() {
    const editor = adapter.getInputElement();
    return editorTools.editorText(editor).trim();
  }

  function createButton(label, callback, className = 'one-brain-extension-save') {
    const button = document.createElement('button');
    button.type = 'button'; button.className = `one-brain-extension-ui ${className}`; button.textContent = label;
    button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); callback(); });
    return button;
  }

  let buttonRefreshFrame = 0, launcherPositionFrame = 0;
  function scheduleButtonRefresh() {
    if (buttonRefreshFrame) return;
    buttonRefreshFrame = window.requestAnimationFrame(() => { buttonRefreshFrame = 0; refreshButtons(); });
  }
  function scheduleLauncherPosition() {
    if (launcherPositionFrame) return;
    launcherPositionFrame = window.requestAnimationFrame(() => {
      launcherPositionFrame = 0;
      const composer = adapter.getInputElement();
      if (composerResizeObserver && composer !== observedComposer) {
        composerResizeObserver.disconnect();
        observedComposer = composer;
        if (composer) composerResizeObserver.observe(composer);
      }
      positionLauncher();
    });
  }
  async function saveMessage(message) {
    try {
      const latestSettings = await askBackground({ type: 'get-settings', site: SITE });
      if (typeof latestSettings?.smartSaveEnabled === 'boolean') config.smartSaveEnabled = latestSettings.smartSaveEnabled;
    } catch {}
    if (smartSaveToggle) smartSaveToggle.checked = config.smartSaveEnabled !== false;
    const text = cleanOutgoingText(message.text || readText(message.element));
    const check = smartSave.scoreMessage(text);
    if (config.smartSaveEnabled !== false && !check.keep) { toast('Smart save is on for this site. Turn it off in One Brain settings to save this message.', true); return; }
    openConfirmation({ kind: 'message', text: check.text, skipSmartFilter: config.smartSaveEnabled === false });
  }

  function renderInputButton() {
    const editor = adapter.getInputElement();
    const buttons = [...document.querySelectorAll('.one-brain-add-memory')];
    if (SITE === 'perplexity') { buttons.forEach((button) => button.remove()); return; }
    for (const button of buttons) if (!config.enabled || !config.showButtons || button._oneBrainEditor !== editor) button.remove();
    if (!config.enabled || !config.showButtons || !editor?.isConnected || buttons.some((button) => button._oneBrainEditor === editor && button.isConnected)) return;
    const button = createButton('Add memory', () => { void openSuggestions('manual'); }, 'one-brain-add-memory');
    button._oneBrainEditor = editor;
    editor.insertAdjacentElement('afterend', button);
  }

  function recentUserMessages() {
    return adapter.getMessages().filter((message) => ['user', 'human'].includes(message.role)).slice(-2).map(({ element }) => cleanOutgoingText(readText(element)).slice(0, 300));
  }

  function refreshButtons() {
    menu.hidden = !config.enabled || !config.showButtons;
    if (smartSaveToggle) smartSaveToggle.checked = config.smartSaveEnabled !== false;
    messageActions.renderSaveButtons(adapter, {
      enabled: config.enabled && config.showButtons,
      isStreaming: replyIsGenerating(),
      createButton: (message) => createButton('Save', () => { void saveMessage(message); })
    });
    renderInputButton();
  }

  function openConfirmation({ kind, text, messages = [], skipSmartFilter = false }) {
    if (!text.trim()) { toast('There is no text to save.', true); return; }
    modal?.remove();
    modal = document.createElement('section');
    modal.className = 'one-brain-extension-modal one-brain-extension-ui';
    const heading = kind === 'chat' ? 'Save chat to One Brain?' : 'Save message to One Brain?';
    const title = kind === 'chat' ? `Saved ${SITE} chat` : text.split(/[.!?\n]/, 1)[0].slice(0, 80) || `Saved from ${SITE}`;
    modal.innerHTML = `<div class="one-brain-extension-dialog"><h2></h2><label>Title<input maxlength="200"></label><div class="one-brain-extension-preview"></div><footer><button type="button" data-cancel>Cancel</button><button type="button" data-save>Save</button></footer></div>`;
    modal.querySelector('h2').textContent = heading;
    modal.querySelector('input').value = title;
    modal.querySelector('.one-brain-extension-preview').textContent = text;
    modal.querySelector('[data-cancel]').addEventListener('click', () => { modal.remove(); modal = null; });
    modal.querySelector('[data-save]').addEventListener('click', async () => {
      const saveButton = modal.querySelector('[data-save]');
      saveButton.disabled = true;
      try {
        const result = await askBackground({ type: 'save', site: SITE, kind, title: modal.querySelector('input').value, text, messages, skipSmartFilter });
        if (!result?.ok) throw new Error(result?.error || 'Could not save to One Brain.');
        modal.remove(); modal = null; toast('Saved to One Brain.');
      } catch (error) { saveButton.disabled = false; toast(error?.message || 'Could not save to One Brain.', true); }
    });
    document.body.append(modal);
  }

  function closeSuggestionPanel() { modal?.remove(); modal = null; }

  async function openManualContext() {
    closeSuggestionPanel();
    modal = document.createElement('section');
    modal.className = 'one-brain-extension-modal one-brain-extension-ui';
    modal.innerHTML = '<div class="one-brain-extension-dialog"><h2>Manual context</h2><label>Question<textarea data-query rows="3"></textarea></label><button type="button" data-search>Search</button><div data-results></div><p data-empty hidden>No strong matches</p><footer><button type="button" data-close>Close</button><button type="button" data-copy disabled>Copy</button></footer></div>';
    const panel = modal, queryInput = panel.querySelector('[data-query]'), resultRoot = panel.querySelector('[data-results]');
    panel.querySelector('[data-close]').addEventListener('click', closeSuggestionPanel);
    panel.querySelector('[data-search]').addEventListener('click', async () => {
      const query = manualContext.stripContextBlocks(queryInput.value).trim();
      resultRoot.replaceChildren(); panel.querySelector('[data-empty]').hidden = true; panel.querySelector('[data-copy]').disabled = true;
      if (!query) { panel.querySelector('[data-empty]').hidden = false; return; }
      try {
        const found = await askBackground({ type: 'search-memories', site: SITE, query, limit: 5 });
        if (!found?.ok) { toast(found?.error || 'Could not search One Brain.', true); return; }
        const memories = (found.memories || []).slice(0, 5);
        if (!manualContext.hasStrongMatches(memories)) { panel.querySelector('[data-empty]').hidden = false; return; }
        memories.forEach((memory) => {
          const row = document.createElement('label'), check = document.createElement('input'), title = document.createElement('strong'), snippet = document.createElement('textarea');
          check.type = 'checkbox'; check.checked = true; check.addEventListener('change', syncCopy);
          title.textContent = String(memory.title || 'Untitled memory'); snippet.value = String(memory.snippet || '');
          row.append(check, title, snippet); resultRoot.append(row);
        });
        syncCopy();
      } catch { panel.querySelector('[data-empty]').hidden = false; }
    });
    function syncCopy() { panel.querySelector('[data-copy]').disabled = !resultRoot.querySelector('input:checked'); }
    panel.querySelector('[data-copy]').addEventListener('click', async () => {
      const memories = [...resultRoot.querySelectorAll('label')].filter((row) => row.querySelector('input').checked).map((row) => ({ source: SITE, title: row.querySelector('strong').textContent, snippet: row.querySelector('textarea').value }));
      const block = manualContext.buildManualBlock(memories);
      try { await navigator.clipboard.writeText(block); closeSuggestionPanel(); toast('Context copied.'); }
      catch { toast('Clipboard unavailable. Allow clipboard access and try again.', true); }
    });
    document.body.append(panel); queryInput.focus();
  }

  let manualButton = null, launcherActions = null, launcherExpanded = false, smartSaveToggle = null;
  const layoutFallback = layoutFallbackModule.createLayoutFallback(() => {
      if (stopped) return;
      toast("One Brain couldn't detect this site's chat composer or send button. Saving chats may still work; context insertion may be unavailable.", true);
      manualButton = createButton('Manual context', () => { void openManualContext(); }, 'one-brain-manual-context');
      launcherActions?.append(manualButton);
  });
  let lastLayoutBroken = null, layoutWarningTimer = null;
  const CONTENT_SCRIPT_VERSION = '1.4.10';
  function reportAdapterLayout(matched, broken) {
    void askBackground({ type: 'adapter-self-check-report', site: SITE, matched, reason: broken ? 'Chat composer controls were not detected; context insertion may be unavailable.' : undefined });
  }
  function checkAdapterLayout() {
    if (stopped) return false;
    const matched = adapter.selfCheck();
    const generating = Boolean(document.querySelector('button[aria-label*="Stop" i],button[title*="Stop" i],[data-testid*="stop" i]'));
    const working = Boolean(matched?.input && (matched?.send || generating));
    if (working) {
      clearScheduledTimeout(layoutWarningTimer); layoutWarningTimer = null;
      if (matched?.send && lastLayoutBroken !== false) { lastLayoutBroken = false; reportAdapterLayout(matched, false); }
      else if (generating && !matched?.send && lastLayoutBroken === true) lastLayoutBroken = null;
      layoutFallback.check(true);
      return true;
    }
    if (layoutWarningTimer == null && lastLayoutBroken !== true) {
      layoutWarningTimer = scheduleTimeout(() => {
        layoutWarningTimer = null;
        if (stopped) return;
        const latest = adapter.selfCheck();
        const stillMissing = Boolean(!latest?.input || !latest?.send) && !document.querySelector('button[aria-label*="Stop" i],button[title*="Stop" i],[data-testid*="stop" i]');
        if (!stillMissing) return;
        lastLayoutBroken = true;
        reportAdapterLayout(latest, true);
        layoutFallback.check(false);
      }, 1500);
    }
    return false;
  }
  const extensionRuntime = globalThis.browser?.runtime || globalThis.chrome?.runtime;
  extensionRuntime?.onMessage?.addListener?.((message, _sender, sendResponse) => {
    if (message?.type !== 'run-self-check') return false;
    const matched = adapter.selfCheck() || {};
    sendResponse({ matched, diagnostics: { containersMatched: matched.containersMatched, messagesByRole: matched.messagesByRole, scrollableFound: matched.scrollableFound, scrollableType: matched.scrollableType, messageSelectors: matched.messageSelectors, selectorNames: matched.selectorNames || {} }, contentScriptVersion: CONTENT_SCRIPT_VERSION });
    return false;
  });

  async function openSuggestions(trigger) {
    const editor = adapter.getInputElement();
    const rawDraft = editorTools.editorText(editor);
    if (trigger === 'auto' && editorTools.hasContextBlocks(rawDraft)) return;
    const originalDraft = editorTools.stripContextBlocks(rawDraft);
    const draft = originalDraft.trim();
    const query = searchIntent.buildSearchQuery(draft, recentUserMessages());
    if (!query) { toast('Write a draft or wait for a message before searching.', true); return; }
    if (!chatState.enabled) { if (trigger === 'manual') toast('Memory suggestions are off for this chat.'); return; }
    closeSuggestionPanel();
    modal = document.createElement('section');
    modal.className = 'one-brain-extension-modal one-brain-suggestion-overlay one-brain-extension-ui';
    modal.innerHTML = `<div class="one-brain-extension-dialog one-brain-suggestions"><h2>One Brain context</h2><p class="one-brain-extension-estimate">Searching…</p><div class="one-brain-extension-results"></div><footer><button type="button" data-cancel>Cancel</button><button type="button" data-insert disabled>Insert</button></footer></div>`;
    const panel = modal;
    if (trigger === 'auto') { panel.querySelector('[data-cancel]').textContent = 'Skip'; panel.querySelector('[data-insert]').textContent = 'Insert (Enter)'; }
    panel.querySelector('[data-cancel]').addEventListener('click', closeSuggestionPanel);
    document.body.append(panel);
    let result;
    try { result = await askBackground({ type: 'search-memories', site: SITE, query, limit: 5, excludeIds: chatState.excludeIds || [] }); }
    catch (error) { result = { ok: false, error: error?.message || 'Could not reach the One Brain extension service.' }; }
    if (modal !== panel || !panel.isConnected) return;
    if (!searchIntent.canShowSearchResult(result)) {
      closeSuggestionPanel();
      if (trigger === 'manual') toast(result?.error || 'Could not search One Brain.', true);
      return;
    }
    const memories = (result.memories || []).slice(0, 5);
    const root = panel.querySelector('.one-brain-extension-results');
    root.replaceChildren();
    if (!memories.length) panel.querySelector('.one-brain-extension-estimate').textContent = 'No matching memories. Your draft is unchanged.';
    for (const memory of memories) {
      const row = document.createElement('div'); row.className = 'one-brain-extension-result'; row.dataset.memoryId = String(memory.id);
      const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = trigger === 'auto';
      const dot = document.createElement('span'); dot.className = 'one-brain-source-dot'; dot.style.backgroundColor = sourceColors[memory.source] || '#8a9aac'; dot.setAttribute('aria-label', String(memory.source || 'source'));
      const body = document.createElement('span'); body.className = 'one-brain-result-copy';
      const title = document.createElement('strong'); title.textContent = String(memory.title || 'Untitled memory');
      const snippet = document.createElement('textarea'); snippet.value = String(memory.snippet || ''); snippet.setAttribute('aria-label', `Context to insert for ${memory.title || 'memory'}`);
      const reason = document.createElement('small'); reason.textContent = String(memory.reason || '');
      body.append(title, snippet, reason);
      const score = document.createElement('span'); score.className = 'one-brain-result-score'; score.textContent = Number.isFinite(Number(memory.score)) ? Number(memory.score).toFixed(2) : '—';
      const actions = document.createElement('div'); actions.className = 'one-brain-memory-actions';
      const irrelevant = document.createElement('button'); irrelevant.type = 'button'; irrelevant.textContent = 'Not relevant';
      irrelevant.addEventListener('click', async () => {
        const previous = chatState.excludeIds || [];
        chatState.excludeIds = [...new Set([...previous, String(memory.id)])].slice(-500);
        try { const saved = await askBackground({ type: 'set-chat-state', chatKey: await getChatKey(), state: chatState }); if (!saved?.ok) throw new Error(); row.remove(); updateSelection(); }
        catch { chatState.excludeIds = previous; toast('Could not update this chat’s exclusions.', true); }
      });
      const never = document.createElement('button'); never.type = 'button'; never.textContent = 'Never suggest';
      never.addEventListener('click', async () => { try { const changed = await askBackground({ type: 'mark-no-suggest', site: SITE, id: memory.id }); if (!changed?.ok) throw new Error(); row.remove(); updateSelection(); } catch { toast('Could not update this memory.', true); } });
      actions.append(irrelevant, never);
      row.append(checkbox, dot, body, score, actions); root.append(row);
      checkbox.addEventListener('change', updateSelection);
    }
    const insert = panel.querySelector('[data-insert]');
    const slider = document.createElement('input'); slider.type = 'range'; slider.min = '100'; slider.max = '1500'; slider.step = '50'; slider.value = String(config.tokenBudget || 1500); slider.setAttribute('aria-label', 'Context token budget');
    const format = document.createElement('select'); for (const [value, label] of [['context', 'Context block'], ['bullet', 'Bullet list']]) { const option = document.createElement('option'); option.value = value; option.textContent = label; format.append(option); } format.value = config.contextFormat || 'context';
    const controls = document.createElement('div'); controls.className = 'one-brain-extension-context-controls'; controls.append(slider, format); root.after(controls);
    function updateSelection() {
      const selectedRows = [...root.querySelectorAll('.one-brain-extension-result')].filter((row) => row.querySelector('input[type="checkbox"]')?.checked);
      const selected = selectedRows.map((row) => { const item = memories.find((memory) => String(memory.id) === row.dataset.memoryId); return item && { ...item, snippet: row.querySelector('textarea').value }; }).filter(Boolean);
      const block = editorTools.composeBlock(selected, { maxTokens: Number(slider.value), format: format.value });
      const estimate = selected.length ? editorTools.contextEstimate(block) : 0;
      const exceeds = estimate > Number(slider.value);
      panel.querySelector('.one-brain-extension-estimate').textContent = `${estimate} / ${slider.value} token estimate`;
      insert.disabled = selected.length === 0 || exceeds;
      insert.dataset.block = exceeds ? '' : block;
      insert.dataset.selected = JSON.stringify(selected.map((item) => ({ id: item.id, source: item.source, title: item.title, text: item.snippet })));
    }
    updateSelection();
    slider.addEventListener('input', updateSelection); format.addEventListener('change', updateSelection);
    async function insertSelected({ automatic = false } = {}) {
      const current = adapter.getInputElement();
      if (!current || editorTools.stripContextBlocks(editorTools.editorText(current)) !== originalDraft) { closeSuggestionPanel(); toast('Draft changed; no context was inserted.'); return false; }
      if (automatic && editorTools.hasContextBlocks(editorTools.editorText(current))) return false;
      const block = insert.dataset.block;
      if (!block) { toast('Choose one or more results within the token budget.', true); return false; }
      const chatKey = await getChatKey();
      const draftKey = `${chatKey}:${await crypto.subtle.digest('SHA-256', new TextEncoder().encode(originalDraft)).then((bytes) => [...new Uint8Array(bytes)].map((part) => part.toString(16).padStart(2, '0')).join(''))}`;
      if (insertedDrafts.has(draftKey)) return false;
      if (automatic) { const attempt = insertionGuard.attempt(chatKey, Date.now()); if (!attempt.allowed) { if (attempt.looped && !loopToastShown) { loopToastShown = true; config.memoryMode = 'ask'; config.insertWithoutAsking = false; toast('Auto-context paused (it looped)', true); void askBackground({type:'set-site-settings',site:SITE,settings:config}); } return false; } }
      const previousText = editorTools.editorText(current);
      programmaticInsertUntil = Date.now() + 500;
      if (current.matches('textarea, input')) editorTools.insertTextarea(current, block);
      else editorTools.insertContentEditable(current, block);
      lastInsertedBlock = block;
      insertedDrafts.add(draftKey);
      const insertedText = editorTools.editorText(current);
      current.focus();
      closeSuggestionPanel();
      if (automatic) {
        toastWithUndo('Context inserted. Undo', () => editorTools.undoInsertion(current, previousText, insertedText));
      } else toast('Context inserted. Review it, then send when ready.');
      return true;
    }
    insert.addEventListener('click', () => { void insertSelected(); });
    panel._oneBrainInsertSelected = insertSelected;
    if (trigger === 'auto' && config.insertWithoutAsking && memories.length) void insertSelected({ automatic: true });
  }

  function isEditorTarget(target) {
    const input = adapter.getInputElement();
    return Boolean(input && (target === input || input.contains(target)));
  }

  function sendIntent(event) {
    if (!config.enabled) return;
    const sendKey = event.type === 'keydown' && event.key === 'Enter' && !event.shiftKey && !event.isComposing && event.keyCode !== 229;
    const sendButton = adapter.getSendButton();
    const sendClick = event.type === 'click' && sendButton && (event.target === sendButton || sendButton.contains(event.target));
    if (!sendKey && !sendClick) return;
    if (sendKey && !isEditorTarget(event.target)) return;
    const editor = adapter.getInputElement();
    let outgoing = cleanOutgoingText(editorTools.editorText(editor));
    if (config.autoSaveMessages && outgoing.trim().length >= 40 && !looksLikeLog(outgoing)) {
      pendingSends.push({ text: outgoing, expires: Date.now() + 30000 });
      scheduleTimeout(confirmSentMessages, 0);
    }
  }

  function confirmSentMessages() {
    pendingSends = pendingSends.filter((item) => item.expires > Date.now());
    if (!pendingSends.length) return;
    const sent = adapter.getMessages().filter((message) => ['user', 'human'].includes(message.role)).map(({ element }) => readText(element));
    for (const pending of [...pendingSends]) {
      if (!sent.includes(pending.text)) continue;
      pendingSends = pendingSends.filter((item) => item !== pending);
      void askBackground({ type: 'auto-save-sent-message', site: SITE, text: pending.text }).then((result) => {
        if (!result?.ok) toast('Could not auto-save this message.', true);
        else toast('Message saved to One Brain.');
      }).catch(() => toast('Could not auto-save this message.', true));
    }
  }

  async function loadConfig() {
    try { config = { ...DEFAULTS, ...(await askBackground({ type: 'get-settings', site: SITE }) || {}) }; }
    catch { config = { ...DEFAULTS, enabled: false, showButtons: false }; }
    refreshButtons();
    scheduleAutoSaveFinishedReply();
  }

  async function loadChatState() {
    try { chatState = { enabled: true, excludeIds: [], ...(await askBackground({ type: 'get-chat-state', chatKey: await getChatKey() }) || {}) }; }
    catch { chatState = { enabled: false, excludeIds: [] }; }
    refreshMenuLabels();
  }

  async function syncChatRoute() {
    if (location.pathname === chatRoutePath) return;
    chatRoutePath = location.pathname;
    chatKeyValue = '';
    chatState = { enabled: true, excludeIds: [] };
    refreshMenuLabels();
    await loadChatState();
  }

  function scheduleIntentSearch(event) {
    if (event.isComposing || !config.enabled || !chatState.enabled || !['ask', 'auto'].includes(config.memoryMode)) return;
    clearScheduledTimeout(autoTimer);
    const editor = adapter.getInputElement();
      const rawSnapshot = editorTools.editorText(editor);
      if (Date.now() < programmaticInsertUntil) return;
      const snapshot = editorTools.stripContextBlocks(rawSnapshot);
      if (snapshot === lastProcessedDraft) return;
      lastProcessedDraft = snapshot;
    if (!searchIntent.detectMemoryIntent(snapshot, config.memoryPhrases || searchIntent.DEFAULT_MEMORY_PHRASES)) return;
    autoTimer = scheduleTimeout(() => {
      if (adapter.getInputElement() !== editor || editorTools.editorText(editor) !== snapshot) return;
      if (editorTools.hasContextBlocks(editorTools.editorText(editor))) return;
      void openSuggestions(config.memoryMode === 'auto' ? 'auto' : 'ask');
    }, 1200);
  }

  function readChatMessages() {
    const found = adapter.getMessages().map(({ id, element, role, text, ts, order }) => ({ id, role, text: cleanOutgoingText(text ?? readText(element)), ts: ts || null, order, element }))
      .filter((message) => message.text && ['user', 'assistant'].includes(message.role));
    return loadedChatMessages ? mergeMessages(loadedChatMessages, found) : found;
  }

  let loadedChatMessages = null;
  function mergeMessages(existing, incoming) {
    return chatLoader.merge(existing, incoming);
  }

  function looksLikeSecret(text) {
    return /\b(?:api[_ -]?key|(?:(?:access|refresh|auth)[_ -]?)?token|password|passwd|secret|client[_ -]?secret)\s*[:=]\s*\S+|\b(?:sk-[A-Za-z0-9_-]{12,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,}|sk_live_[A-Za-z0-9]{12,})\b|\bAuthorization\s*:\s*Bearer\s+\S+|\b(?:gh[pousr]_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{12,})\b|-----BEGIN [A-Z ]*PRIVATE KEY-----|\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b/i.test(String(text || ''));
  }

  const attemptedAutoSaveHashes = new Set();
  const inflightAutoSaveHashes = new Set();
  let autoReplyTimer = null, autoReplyCandidate = '', lockedAutoSaveNoticeShown = false;
  function replyIsGenerating() {
    return !!document.querySelector('button[aria-label*="Stop" i],button[title*="Stop" i],[data-testid*="stop" i]');
  }
  function latestExchange() {
    const messages = adapter.getMessages().map(({ role, text, element }) => ({ role, text: cleanOutgoingText(text ?? readText(element)) }))
      .filter((message) => message.text && ['user', 'assistant'].includes(message.role));
    const assistantIndex = messages.length - 1;
    if (assistantIndex < 1 || messages[assistantIndex].role !== 'assistant') return null;
    let userIndex = assistantIndex - 1;
    while (userIndex >= 0 && messages[userIndex].role !== 'user') userIndex--;
    return userIndex >= 0 ? [messages[userIndex], messages[assistantIndex]] : null;
  }
  async function sha256(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return [...new Uint8Array(digest)].map((part) => part.toString(16).padStart(2, '0')).join('');
  }
  function titleFromExchange(text) {
    const cleaned = String(text || '').split(/\r?\n/).map((line) => line.trim())
      .filter((line) => line && !/^\d{1,2}:\d{2}\s?(?:AM|PM)$/i.test(line) && !/^(?:sources?|\w[\w .'-]{2,50}·(?:January|February|March|April|May|June|July|August|September|October|November|December)\b)/i.test(line));
    const heading = cleaned.find((line) => /^#{1,6}\s+/.test(line));
    return (heading ? heading.replace(/^#{1,6}\s+/, '') : (cleaned[0] || 'Saved chat').split(/(?<=[.!?])\s/)[0]).slice(0, 160);
  }
  async function autoSaveFinishedReply(exchange, fingerprint) {
    if (attemptedAutoSaveHashes.has(fingerprint) || inflightAutoSaveHashes.has(fingerprint)) return;
    inflightAutoSaveHashes.add(fingerprint);
    try {
      let messages = exchange.map((message) => ({ ...message }));
      if (messages.some((message) => looksLikeSecret(message.text) || looksLikeLog(message.text))) { attemptedAutoSaveHashes.add(fingerprint); return; }
      if (config.smartSaveEnabled !== false) {
        messages = smartSave.prepareSmartSave(messages, { includeAssistant: true }).kept;
        if (messages.length < 2) { attemptedAutoSaveHashes.add(fingerprint); return; }
      }
      const result = await askBackground({ type: 'auto-save-finished-reply', site: SITE, hash: fingerprint, payload: {
        chatKey: await getChatKey(), title: titleFromExchange(exchange[0].text), source: SITE,
        messages: messages.map(({ role, text }, index) => ({ id: `${fingerprint}:${index}`, role, text })),
      } });
      attemptedAutoSaveHashes.add(fingerprint);
      if (result?.locked) {
        if (!lockedAutoSaveNoticeShown) { lockedAutoSaveNoticeShown = true; toast('One Brain is locked. Unlock it before automatic saving can continue.'); }
        return;
      }
      if (!result?.ok || result.duplicate || !(Number(result.inserted) > 0) || !result.importId) return;
      toastWithUndo('Saved to One Brain', async () => {
        const undone = await askBackground({ type: 'undo-chat-save', site: SITE, importId: result.importId, hash: fingerprint });
        return undone?.ok === true;
      }, { duration: 10_000, successMessage: 'Save undone.' });
    } catch {
      attemptedAutoSaveHashes.add(fingerprint);
    } finally { inflightAutoSaveHashes.delete(fingerprint); }
  }
  function scheduleAutoSaveFinishedReply() {
    if (!config.enabled || config.autoSaveFinishedReplies !== true || replyIsGenerating()) { clearScheduledTimeout(autoReplyTimer); autoReplyTimer = null; autoReplyCandidate = ''; return; }
    const exchange = latestExchange();
    if (!exchange) { autoReplyCandidate = ''; return; }
    const signature = JSON.stringify(exchange.map(({ role, text }) => [role, text]));
    if (signature === autoReplyCandidate) return;
    clearScheduledTimeout(autoReplyTimer); autoReplyTimer = null;
    autoReplyCandidate = signature;
    autoReplyTimer = scheduleTimeout(() => {
      autoReplyTimer = null;
      if (!config.enabled || config.autoSaveFinishedReplies !== true || replyIsGenerating()) { autoReplyCandidate = ''; return; }
      const latest = latestExchange();
      if (!latest || JSON.stringify(latest.map(({ role, text }) => [role, text])) !== signature) { autoReplyCandidate = ''; scheduleAutoSaveFinishedReply(); return; }
      void sha256(signature).then((fingerprint) => autoSaveFinishedReply(latest, fingerprint)).catch(() => {});
    }, 2000);
  }

  async function loadFullChat(panel, status, cancelState) {
    const progress = panel.querySelector('[data-load-progress]');
    const initial = adapter.getMessages();
    const scroller = adapter.findScrollContainer?.(initial) || null;
    if (!scroller) { progress.textContent = 'Nothing more to load.'; status.textContent = ''; return; }
    progress.textContent = 'Scrolling through chat history…';
    const result = await chatLoader.loadFullChat({ scroller, collect: readChatMessages, cancelled: () => cancelState.cancelled, wait: (ms) => new Promise((resolve) => setTimeout(resolve, Math.max(1, ms))), maxSteps: SITE === 'perplexity' ? 30 : 300, mode: SITE === 'perplexity' ? 'scroll-to-top-stable' : 'history', stableMs: 1500, progress: (count) => { progress.textContent = `${count} messages loaded`; } });
    loadedChatMessages = result.messages.map(({ element, ...message }) => message);
    progress.textContent = result.cancelled ? `${result.messages.length} messages loaded · cancelled` : result.nothingMoreToLoad ? 'Nothing more to load.' : `${result.messages.length} messages loaded`;
    status.textContent = '';
  }

  async function openChatSaveDialog() {
    closeSuggestionPanel();
    modal?.remove();
    const key = await getChatKey();
    let state = { saved: false };
    try { state = await askBackground({ type: 'chat-save-state', site: SITE, chatKey: key }) || state; } catch {}
    if (!state.ok && state.error) { toast(state.error, true); return; }
    modal = document.createElement('section');
    modal.className = 'one-brain-extension-modal one-brain-extension-ui';
    modal.innerHTML = `<div class="one-brain-extension-dialog one-brain-chat-save-dialog"><h2>Save this chat</h2>
      <section class="one-brain-load-controls"><button type="button" data-load>Load full chat</button><button type="button" data-cancel-load>Cancel loading</button><span data-load-progress></span></section><p data-message-status></p>
      <label>Title<input data-title maxlength="160"></label><label>Source<select data-source></select></label>
      <label>Scope<select data-scope><option value="whole">Whole chat</option><option value="from">From the selected message on</option><option value="pick">Pick messages</option></select></label>
      <label data-from-label hidden>Start at<select data-from></select></label><div data-pick-actions hidden><button type="button" data-select-all>Select all</button><button type="button" data-select-none>Select none</button></div><div data-pick class="one-brain-chat-picks" hidden></div>
      <label>Include<select data-include><option value="my-messages">My messages only</option><option value="both">My messages + assistant replies</option><option value="both-truncated">Both, assistant replies cut to 600 characters</option></select></label>
      <label>Save mode<select data-save-mode><option value="smart" selected>Smart (important only)</option><option value="all">All matching messages</option></select></label><label>Importance<select data-importance><option>Strict</option><option selected>Normal</option><option>Loose</option></select></label>
      <label>Split<select data-split><option value="exchange">By exchange</option><option value="topic">By topic</option><option value="fixed">Fixed size (~1,200 characters)</option><option value="one">One memory</option></select></label>
      <p data-one-warning hidden>One memory keeps the whole chat in a single record. Search embeddings cover only the beginning of long text; a split is recommended.</p>
      <label><input type="checkbox" data-skip-logs checked>Skip log-like text</label><label><input type="checkbox" data-skip-secrets checked>Skip text that looks like secrets</label><label><input type="checkbox" data-private>Mark all as private</label>
      <div data-preview hidden></div><div data-save-progress class="one-brain-save-progress" hidden><i></i></div>
      <footer><button type="button" data-cancel>Cancel</button><button type="button" data-preview-button>Preview</button><button type="button" data-save hidden>Save</button><button type="button" data-only-new hidden>Save only new messages</button></footer></div>`;
    const panel = modal;
    document.body.append(panel);
    panel.querySelector('[data-save-mode]').value = 'all';
    const source = panel.querySelector('[data-source]');
    for (const value of ['chatgpt', 'claude', 'gemini', 'codex', 'groq', 'deepseek', 'perplexity']) { const option = document.createElement('option'); option.value = value; option.textContent = value; source.append(option); }
    source.value = SITE;
    const titleInput = panel.querySelector('[data-title]');
    titleInput.value = String(document.title || `Saved ${SITE} chat`).replace(/\s*[|–-]\s*(ChatGPT|Claude|Gemini).*$/i, '').slice(0, 160);
    const startsAt = panel.querySelector('[data-from]');
    const picks = panel.querySelector('[data-pick]');
    function renderMessageSelectors() {
      const list = readChatMessages();
      const messageStatus = panel.querySelector('[data-message-status]');
      const yours = list.filter((message) => message.role === 'user').length, assistant = list.filter((message) => message.role === 'assistant').length;
      const longChat = (adapter.findScrollContainer?.(adapter.getMessages())?.scrollHeight || 0) > 2500;
      const historyHint = adapter.historyComplete ? ' Perplexity exposes the messages currently in this thread.' : ' Press Load full chat or scroll to the top first.';
      messageStatus.textContent = list.length ? `${list.length} messages detected: ${yours} yours, ${assistant} assistant${list.length === 1 || (longChat && list.length < 4) ? `.${historyHint}` : '.'}` : `No readable chat messages detected.${historyHint}`;
      startsAt.replaceChildren(); picks.replaceChildren();
      list.forEach((message, index) => {
        const hiddenText = looksLikeSecret(message.text) ? '[secret-looking text hidden]' : message.text.split(/\r?\n/, 1)[0].slice(0, 100);
        const option = document.createElement('option'); option.value = String(index); option.textContent = `${message.role}: ${hiddenText}`; startsAt.append(option);
        const label = document.createElement('label'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = true; checkbox.value = String(index);
        const preview = document.createElement('span'); preview.textContent = `${message.role}: ${looksLikeSecret(message.text) ? '[secret-looking text hidden]' : message.text.slice(0, 120)}`;
        label.append(checkbox, preview); picks.append(label);
      });
    }
    renderMessageSelectors();
    panel.querySelector('[data-scope]').addEventListener('change', (event) => { panel.querySelector('[data-from-label]').hidden = event.target.value !== 'from'; picks.hidden = event.target.value !== 'pick'; panel.querySelector('[data-pick-actions]').hidden = event.target.value !== 'pick'; });
    panel.querySelector('[data-select-all]').addEventListener('click', () => picks.querySelectorAll('input[type="checkbox"]').forEach((item) => { item.checked = true; }));
    panel.querySelector('[data-select-none]').addEventListener('click', () => picks.querySelectorAll('input[type="checkbox"]').forEach((item) => { item.checked = false; }));
    panel.querySelector('[data-split]').addEventListener('change', (event) => { panel.querySelector('[data-one-warning]').hidden = event.target.value !== 'one'; });
    const loadStatus = panel.querySelector('[data-load-progress]');
    const cancelState = { cancelled: false };
    panel.querySelector('[data-load]').addEventListener('click', () => { cancelState.cancelled = false; void loadFullChat(panel, loadStatus, cancelState).then(renderMessageSelectors).catch(() => { if (panel.isConnected) loadStatus.textContent = 'Could not load chat history. Scroll up manually and try again.'; }); });
    panel.querySelector('[data-cancel-load]').addEventListener('click', () => { cancelState.cancelled = true; });
    panel.querySelector('[data-cancel]').addEventListener('click', () => { cancelState.cancelled = true; panel.remove(); if (modal === panel) modal = null; });
    const preview = panel.querySelector('[data-preview]');
    const saveButton = panel.querySelector('[data-save]'), newButton = panel.querySelector('[data-only-new]');
    function selectedMessages() {
      const all = readChatMessages(); const scope = panel.querySelector('[data-scope]').value;
      if (scope === 'from') return all.slice(Number(startsAt.value) || 0);
      if (scope === 'pick') { const selected = new Set([...picks.querySelectorAll('input:checked')].map((item) => Number(item.value))); return all.filter((_item, index) => selected.has(index)); }
      return all;
    }
    let restoredIds = [], previewItems = [];
    function inspectPayload({applySmart=true}={}) {
      const include = panel.querySelector('[data-include]').value;
      let messages = selectedMessages().filter((item) => include !== 'my-messages' || item.role === 'user').map(({ id, role, text, ts }) => ({ id, role, text: role === 'assistant' && include === 'both-truncated' ? text.slice(0, 600) : text, ts }));
      const skipSecrets = panel.querySelector('[data-skip-secrets]').checked;
      const skipLogs = panel.querySelector('[data-skip-logs]').checked;
      let skippedSecrets = 0, skippedLogs = 0;
      messages = messages.filter((item) => { if (skipSecrets && looksLikeSecret(item.text)) { skippedSecrets++; return false; } if (skipLogs && looksLikeLog(item.text)) { skippedLogs++; return false; } return true; });
      messages = messages.map((m) => ({...m,text:editorTools.stripContextBlocks(m.text)}));
      if (applySmart && panel.querySelector('[data-save-mode]').value === 'smart') { const result = smartSave.prepareSmartSave(messages,{importance:panel.querySelector('[data-importance]').value,includeAssistant:include!=='my-messages',restoredIds}); messages=result.kept; }
      return { messages, skippedSecrets, skippedLogs };
    }
    function payload(onlyNew) {
      const { messages } = inspectPayload();
      return { site: SITE, chatKey: key, title: titleInput.value.trim(), source: source.value, messages, ...(!previewItems.length ? {} : {selectedItems:previewItems.filter((item)=>item.selected).map(({title,content})=>({title,content}))}), include: panel.querySelector('[data-include]').value, split: panel.querySelector('[data-split]').value, onlyNew, options: { skipLogs: panel.querySelector('[data-skip-logs]').checked, skipSecrets: panel.querySelector('[data-skip-secrets]').checked, markPrivate: panel.querySelector('[data-private]').checked } };
    }
    async function showPreview() {
      previewItems=[];
      preview.replaceChildren(); preview.hidden = false;
      const summary = document.createElement('p'); summary.textContent = 'Preparing a safe preview…'; preview.append(summary);
      try {
        const result = await askBackground({ type: 'preview-chat', site: SITE, payload: payload(false) });
        if (!result?.ok) throw new Error(result?.error || 'Could not prepare the chat preview.');
        preview.replaceChildren();
        previewItems=(result.items||[]).map((item)=>({...item,selected:true}));
        const details = document.createElement('p'); details.textContent = `${result.count} memories · ${result.totalChars.toLocaleString()} characters · skipped ${result.skippedLogs} log chunks, ${result.skippedSecrets} secret-looking chunks${result.savedBefore ? ` · ${result.skippedDuplicates} already saved` : ''}`;
        preview.append(details);
        previewItems.forEach((item,index) => { const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.checked=true;check.addEventListener('change',()=>{item.selected=check.checked;});const title=document.createElement('input');title.value=item.title;title.addEventListener('input',()=>item.title=title.value);const body=document.createElement('textarea');body.value=item.content;body.addEventListener('input',()=>item.content=editorTools.stripContextBlocks(body.value));label.append(check,title,body);preview.append(label); });
        const stateInfo=smartSave.prepareSmartSave(inspectPayload({applySmart:false}).messages,{importance:panel.querySelector('[data-importance]').value,includeAssistant:panel.querySelector('[data-include]').value!=='my-messages',restoredIds});
        const counts=document.createElement('p');counts.textContent=`Smart preview: ${stateInfo.keptCount} kept · ${stateInfo.droppedCount} dropped`;preview.prepend(counts);
        if(stateInfo.dropped.length){const detailsList=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Show dropped';detailsList.append(summary);stateInfo.dropped.forEach((item)=>{const row=document.createElement('div'),restore=document.createElement('button');row.textContent=item.text.slice(0,60)+' ';restore.type='button';restore.textContent='Restore';restore.addEventListener('click',()=>{restoredIds.push(item.id);void showPreview();});row.append(restore);detailsList.append(row);});preview.append(detailsList);}
        saveButton.hidden = false; newButton.hidden = !state.saved;
      } catch (error) { preview.replaceChildren(); const failure = document.createElement('p'); failure.textContent = error?.message || 'Could not prepare the chat preview.'; preview.append(failure); saveButton.hidden = true; newButton.hidden = true; }
    }
    panel.querySelector('[data-preview-button]').addEventListener('click', showPreview);
    async function save(onlyNew) {
      const data = payload(onlyNew);
      if (!data.messages.length && !data.selectedItems?.length) { toast('No messages remain after the selected filters.', true); return; }
      const progress = panel.querySelector('[data-save-progress]'); progress.hidden = false; saveButton.disabled = true; newButton.disabled = true;
      try {
        const result = await askBackground({ type: 'save-chat', site: SITE, payload: data });
        if (result?.code === 'chat_already_saved') { state.saved = true; saveButton.disabled = false; newButton.disabled = false; newButton.hidden = false; toast('Choose “Save only new messages” to skip previously saved content.'); return; }
        if (!result?.ok) throw new Error(result?.error || 'Chat save failed.');
        progress.querySelector('i').style.width = '100%';
        panel.querySelector('.one-brain-chat-save-dialog').innerHTML = `<h2>Chat saved</h2><p data-summary></p><button type="button" data-undo>Undo this save</button><footer><button type="button" data-close>Close</button></footer>`;
        panel.querySelector('[data-summary]').textContent = `${result.inserted} memories saved · ${result.skippedDuplicates} duplicates · ${result.skippedLogs} log chunks · ${result.skippedSecrets} secret-looking chunks skipped.`;
        if (!result.importId) panel.querySelector('[data-undo]').remove();
        else panel.querySelector('[data-undo]').addEventListener('click', async () => { const undone = await askBackground({ type: 'undo-chat-save', site: SITE, importId: result.importId }); if (undone?.ok) { panel.querySelector('[data-summary]').textContent = 'This chat save was undone.'; panel.querySelector('[data-undo]').remove(); } else toast('Could not undo this chat save.', true); });
        panel.querySelector('[data-close]').addEventListener('click', () => { panel.remove(); if (modal === panel) modal = null; });
      } catch (error) { toast(error?.message || 'Chat save failed.', true); saveButton.disabled = false; newButton.disabled = false; }
    }
    saveButton.addEventListener('click', () => { void save(false); });
    newButton.addEventListener('click', () => { void save(true); });
  }

  const menu = document.createElement('button');
  menu.type = 'button'; menu.className = 'one-brain-extension-ui one-brain-extension-menu'; menu.textContent = 'Save whole chat';
  menu.addEventListener('click', () => { launcherExpanded = false; launcher.dataset.expanded = 'false'; launcherActions.hidden = true; launcherButton.setAttribute('aria-expanded', 'false'); void openChatSaveDialog(); });
  const removeContext = document.createElement('button');
  removeContext.type = 'button'; removeContext.className = 'one-brain-extension-ui one-brain-remove-context'; removeContext.textContent = 'Remove context';
  removeContext.addEventListener('click', () => { launcherExpanded = false; launcher.dataset.expanded = 'false'; launcherActions.hidden = true; launcherButton.setAttribute('aria-expanded', 'false'); const editor = adapter.getInputElement(); if (!editor) return; const cleaned = editorTools.stripContextBlocks(editorTools.editorText(editor)); if (cleaned !== editorTools.editorText(editor)) { programmaticInsertUntil = Date.now() + 500; editorTools.replaceEditor(editor, cleaned); lastInsertedBlock = ''; toast('Context removed from this draft.'); } });
  const chatMemoryToggle = document.createElement('button'); chatMemoryToggle.type = 'button'; chatMemoryToggle.className = 'one-brain-extension-ui one-brain-chat-toggle';
  chatMemoryToggle.addEventListener('click', async () => {
    const previous = chatState.enabled; chatState.enabled = !previous;
    try { const saved = await askBackground({ type: 'set-chat-state', chatKey: await getChatKey(), state: chatState }); if (!saved?.ok) throw new Error(); refreshMenuLabels(); }
    catch { chatState.enabled = previous; refreshMenuLabels(); toast('Could not update this chat’s memory setting.', true); }
  });
  function refreshMenuLabels() { chatMemoryToggle.textContent = `Memory for this chat: ${chatState.enabled ? 'on' : 'off'}`; }
  const launcher = document.createElement('aside'); launcher.className = 'one-brain-extension-ui one-brain-extension-launcher'; launcher.dataset.expanded = 'false';
  launcherActions = document.createElement('div'); launcherActions.className = 'one-brain-launcher-actions'; launcherActions.hidden = true;
  const launcherButton = document.createElement('button'); launcherButton.type = 'button'; launcherButton.className = 'one-brain-launcher-toggle'; launcherButton.textContent = 'One Brain'; launcherButton.setAttribute('aria-expanded', 'false'); launcherButton.title = 'Open One Brain actions';
  launcherButton.addEventListener('click', () => { launcherExpanded = !launcherExpanded; launcher.dataset.expanded = String(launcherExpanded); launcherActions.hidden = !launcherExpanded; launcherButton.setAttribute('aria-expanded', String(launcherExpanded)); });
  const addMemoryButton = createButton('Add memory', () => { launcherExpanded = false; launcher.dataset.expanded = 'false'; launcherActions.hidden = true; launcherButton.setAttribute('aria-expanded', 'false'); void openSuggestions('manual'); }, 'one-brain-manual-context');
  smartSaveToggle = document.createElement('input'); smartSaveToggle.type = 'checkbox'; smartSaveToggle.checked = config.smartSaveEnabled !== false;
  const smartSaveLabel = document.createElement('label'); smartSaveLabel.className = 'one-brain-smart-save-toggle'; smartSaveLabel.append(smartSaveToggle, document.createTextNode('Smart save filter (important only)'));
  smartSaveToggle.addEventListener('change', async () => {
    const previous = config.smartSaveEnabled !== false;
    const next = smartSaveToggle.checked;
    config.smartSaveEnabled = next;
    const result = await askBackground({ type: 'set-site-settings', site: SITE, settings: { ...config, smartSaveEnabled: next } }).catch(() => null);
    if (!result?.ok) { config.smartSaveEnabled = previous; smartSaveToggle.checked = previous; toast('Could not update this site’s Smart save setting.', true); }
  });
  launcherActions.append(menu, addMemoryButton, smartSaveLabel, chatMemoryToggle, removeContext);
  launcher.append(launcherActions, launcherButton);
  document.documentElement.append(launcher);
  function positionLauncher() { floatingLayout.positionLauncher(launcher, window.innerHeight, window.innerWidth, 16); }
  window.addEventListener('resize', scheduleLauncherPosition, { signal: eventController.signal });
  const cleanupIgnoredScroll = floatingLayout.observeIgnoredScroll(window, (event) => {
    try { if (localStorage.onebrainDebug === '1') console.debug('[onebrain] ignored non-viewport scroll', { target: event.target?.nodeName || 'unknown' }); } catch {}
  });
  let composerResizeObserver = null, observedComposer = null;
  if (typeof ResizeObserver === 'function') { composerResizeObserver = new ResizeObserver(scheduleLauncherPosition); observedComposer = adapter.getInputElement(); if (observedComposer) composerResizeObserver.observe(observedComposer); }
  positionLauncher();
  document.addEventListener('keydown', sendIntent, { capture: true, signal: eventController.signal });
  document.addEventListener('click', sendIntent, { capture: true, signal: eventController.signal });
  document.addEventListener('input', scheduleIntentSearch, { capture: true, signal: eventController.signal });
  document.addEventListener('input', scheduleLauncherPosition, { capture: true, signal: eventController.signal });
  document.addEventListener('focusin', scheduleLauncherPosition, { capture: true, signal: eventController.signal });
  window.addEventListener('popstate', () => { scheduleButtonRefresh(); void syncChatRoute(); }, { signal: eventController.signal });
  window.addEventListener('hashchange', scheduleButtonRefresh, { signal: eventController.signal });

  runtimeMessageListener = (message, _sender, sendResponse) => {
    if (message?.type === 'adapter-self-check') { sendResponse({ site: SITE, matched: adapter.selfCheck() }); return false; }
    if (message?.type === 'settings-changed' && message.site === SITE) { config = { ...DEFAULTS, ...message.settings }; refreshButtons(); scheduleAutoSaveFinishedReply(); }
    return false;
  };
  API.runtime.onMessage.addListener(runtimeMessageListener);

  storageChangedListener = (changes, area) => {
    if (area !== 'local' || !changes.oneBrainSettings) return;
    config = { ...DEFAULTS, ...(changes.oneBrainSettings.newValue?.[SITE] || {}) };
    refreshButtons();
    scheduleAutoSaveFinishedReply();
  };
  API.storage.onChanged.addListener(storageChangedListener);

  void loadConfig();
  void loadChatState();
  const cleanupContentObserver = adapter.observe(() => { if (stopped) return; scheduleButtonRefresh(); confirmSentMessages(); scheduleAutoSaveFinishedReply(); void syncChatRoute(); });
  const cleanupLayoutObserver = adapter.observe(() => { checkAdapterLayout(); });
  adapterCleanup = () => { cleanupContentObserver?.(); cleanupLayoutObserver?.(); composerResizeObserver?.disconnect(); cleanupIgnoredScroll(); if (buttonRefreshFrame) window.cancelAnimationFrame(buttonRefreshFrame); if (launcherPositionFrame) window.cancelAnimationFrame(launcherPositionFrame); };
  refreshButtons();
  checkAdapterLayout();
})();
